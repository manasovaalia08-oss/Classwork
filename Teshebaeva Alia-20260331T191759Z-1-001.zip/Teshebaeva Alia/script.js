let tasks = JSON.parse(localStorage.getItem("tasks"));
if (!tasks) {
    tasks = [];
}
renderTasks(); 
updateStats(); 
showLastVisit(); 



function addTask() {
    const input = document.getElementById("taskInput");
    const text = input.value;
    if (text === "") return;
    const task = {
        id: Date.now(),
        text: text,
        isCompleted: false
    };
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    renderTasks();
    updateStats(); // Обновляем счетчик при добавлении
    input.value = "";
}

//2
function renderTasks() {
    const taskList = document.getElementById("taskList");
    taskList.innerHTML = "";

    for (let i = 0; i < tasks.length; i++) {
        const li = document.createElement("li");
        
        // Добавим стиль для li, чтобы задачи не слипались
        li.style.marginBottom = "8px";
        li.style.display = "flex";
        li.style.justifyContent = "space-between";

        const span = document.createElement("span");
        span.textContent = tasks[i].text;
        span.style.cursor = "pointer";

        if (tasks[i].isCompleted) {
            span.style.textDecoration = "line-through";
            span.style.opacity = "0.6"; 
        }

        span.onclick = function() {
            toggleTask(tasks[i].id);
        };

        li.appendChild(span);
        taskList.appendChild(li);
    }
}

function toggleTask(id) {
    for (let i = 0; i < tasks.length; i++) {
        if (tasks[i].id === id) {
            tasks[i].isCompleted = !tasks[i].isCompleted;
        }
    }

    localStorage.setItem("tasks", JSON.stringify(tasks));
    renderTasks();
    updateStats(); 
}

// 3
let theme = localStorage.getItem("theme");
if (!theme) {
    theme = "light";
}

applyTheme();

const themeBtn = document.getElementById("themeBtn") || document.createElement("button");
themeBtn.id = "themeBtn";
themeBtn.textContent = "Сменить тему";
themeBtn.style.width = "100%";
themeBtn.style.marginTop = "10px";
themeBtn.onclick = changeTheme;


if (!document.getElementById("themeBtn")) {
    document.querySelector(".app-card").appendChild(themeBtn);
}

function changeTheme() {
    theme = (theme === "light") ? "dark" : "light";
    localStorage.setItem("theme", theme);
    applyTheme();
}

function applyTheme() {
    const card = document.querySelector(".app-card");
    const taskList = document.getElementById("taskList"); // Берем список задач

    if (theme === "dark") {
        document.body.style.background = "#222";
        document.body.style.color = "white";
        card.style.background = "#333";
        card.style.color = "white"; 
        taskList.style.color = "white"; 
    } else {
        document.body.style.background = "#f0f2f5";
        document.body.style.color = "black";
        card.style.background = "white";
        card.style.color = "black";
        taskList.style.color = "black"; 
    }
}

//4
function updateStats() {
    const storageStatus = document.getElementById("storageStatus");
    if (!storageStatus) return;

    let completed = 0;
    for (let i = 0; i < tasks.length; i++) {
        if (tasks[i].isCompleted) {
            completed++;
        }
    }

    if (tasks.length === 0) {
        storageStatus.textContent = "Пусто";
    } else {
        storageStatus.textContent = "Всего: " + tasks.length + " | Выполнено: " + completed;
    }
}

function clearStorage() {
    localStorage.removeItem("tasks");
    tasks = [];
    renderTasks();
    updateStats();
}

function showLastVisit() {
    const last = localStorage.getItem("lastVisit");

    if (last) {
        console.log("Прошлый визит был: " + last);
    }
    localStorage.setItem("lastVisit", new Date().toLocaleString());
}
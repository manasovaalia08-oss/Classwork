// Основные элементы
const list = document.querySelector('#task-parent');
const taskInput = document.createElement('input');
const addBtn = document.createElement('button');
const filterInput = document.createElement('input');
const counter = document.createElement('div');

let preview = null; // для "живого" черновика

// Настройка полей
taskInput.type = 'text';
taskInput.placeholder = 'Что нужно сделать?';
addBtn.textContent = 'Добавить';
filterInput.placeholder = 'Поиск по задачам...';

// Раскидываем элементы на странице
list.before(filterInput, taskInput, addBtn);
list.after(counter);

// Функция для создания новой строки в списке
function makeTask(text, isDraft = false) {
    const li = document.createElement('li');
    li.className = 'task-item';
    if (isDraft) li.classList.add('preview');

    li.innerHTML = `
        <span>${text}</span>
        <button class="edit-btn">Редактировать</button>
        <button class="delete-btn">Удалить</button>
    `;
    return li;
}

// Обновляем циферки
function updateCounter() {
    const count = list.querySelectorAll('.task-item:not(.preview)').length;
    counter.textContent = `Всего задач: ${count}`;
}

// Делегирование событий на списке (один обработчик на всё)
list.addEventListener('click', (e) => {
    const target = e.target;
    const item = target.closest('.task-item');
    
    if (!item || item.classList.contains('preview')) return;

    // Кнопка удаления
    if (target.closest('.delete-btn')) {
        item.remove();
        updateCounter();
    } 
    // Кнопка редактирования
    else if (target.closest('.edit-btn')) {
        const span = item.querySelector('span');
        const oldText = span.textContent;
        const newText = prompt('Редактировать задачу:', oldText);
        
        if (newText && newText.trim()) {
            span.textContent = newText.trim();
        }
    } 
    // Просто клик по задаче (выполнение)
    else {
        item.classList.toggle('completed');
    }
});

// Живой поиск
filterInput.addEventListener('input', () => {
    const val = filterInput.value.toLowerCase();
    const tasks = list.querySelectorAll('.task-item:not(.preview)');
    
    tasks.forEach(task => {
        const text = task.querySelector('span').textContent.toLowerCase();
        task.style.display = text.includes(val) ? '' : 'none';
    });
});

// Тот самый Live Preview
taskInput.addEventListener('input', () => {
    const val = taskInput.value.trim();

    if (!val) {
        if (preview) {
            preview.remove();
            preview = null;
        }
        return;
    }

    if (!preview) {
        preview = makeTask(val, true);
        list.append(preview);
    } else {
        preview.querySelector('span').textContent = val;
    }
});

// Функция добавления (чтобы не дублировать код для кнопки и Enter)
function addNewTask() {
    const val = taskInput.value.trim();
    if (!val) return;

    if (preview) {
        preview.remove();
        preview = null;
    }

    list.append(makeTask(val));
    updateCounter();
    taskInput.value = '';
}

addBtn.onclick = addNewTask;

// Горячие клавиши
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        e.preventDefault();
        alert('Escape не работает!');
    }

    if (e.key === 'Enter' && document.activeElement === taskInput) {
        addNewTask();
    }
});

// Работа с сеткой (если она есть)
const gridContainer = document.querySelector('#grid-container');
if (gridContainer) {
    gridContainer.addEventListener('click', (e) => {
        const box = e.target.closest('.box');
        if (box) {
            gridContainer.querySelectorAll('.box').forEach(b => b.classList.remove('active'));
            box.classList.add('active');
        }
    });
}

// Запускаем счетчик при старте
updateCounter();


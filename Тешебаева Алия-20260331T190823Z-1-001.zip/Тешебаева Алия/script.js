const display = document.getElementById("display");
const logContainer = document.getElementById("consoleLogs");

function customLog(message) {
    console.log(message);
    logContainer.innerHTML = logContainer.innerHTML + "> " + message + "<br>";
}

function runEventLoopDemo() {
    logContainer.innerHTML = "> Консоль браузера:<br>";
    customLog("Начало синхронного кода");

    setTimeout(function () {
        customLog("Макрозадача: setTimeout (0 ms)");
    }, 0);

    Promise.resolve().then(function () {
        customLog("Микрозадача: Promise.then");
    });

    customLog("Конец синхронного кода");
    display.textContent = "Смотри порядок в консоли браузера";
}

function runDeadlock() {
    display.textContent = "Браузер завис на 3 сек...";
    customLog("Начало тяжелого кода");

    var start = Date.now();
    while (Date.now() - start < 3000) {
    }

    customLog("Цикл завершен");
    display.textContent = "Ожил!";
}

function checkLuck() {
    return new Promise(function (resolve, reject) {
        display.textContent = "Гадаем...";

        setTimeout(function () {
            var random = Math.random();

            if (random > 0.5) {
                resolve("Успех!");
            } else {
                reject("Ошибка :(");
            }
        }, 1500);
    });
}

function runPromiseRace() {
    checkLuck().then(function (result) {
        display.textContent = result;
        customLog(result);
    }).catch(function (error) {
        display.textContent = error;
        customLog(error);
    }).finally(function () {
        customLog("Проверка завершена");
    });
}

function fakeFetch(name, time) {
    return new Promise(function (resolve) {
        setTimeout(function () {
            customLog("Данные " + name + " получены");
            resolve("Данные " + name);
        }, time);
    });
}

function runParallelTasks() {
    display.textContent = "Загрузка файлов...";
    customLog("Старт загрузки");

    var startTime = Date.now();

    Promise.all([
        fakeFetch("User", 2000),
        fakeFetch("Posts", 1000),
        fakeFetch("Settings", 1500)
    ]).then(function (results) {

        var endTime = Date.now();
        var seconds = (endTime - startTime) / 1000;

        display.textContent = "Все загружено за " + seconds + " сек";
        customLog("Результат: " + results.join(", "));
    }).catch(function () {
        customLog("Ошибка загрузки");
    });
}

const timerInput = document.getElementById("timerInput");
const startBtn = document.getElementById("startTimerBtn");
const resetBtn = document.getElementById("resetTimerBtn");
const timerDisplay = document.getElementById("timerDisplay");

var interval;
var rejectFunction;

function wait(seconds) {
    return new Promise(function (resolve, reject) {
        rejectFunction = reject;

        setTimeout(function () {
            resolve("Время вышло!");
        }, seconds * 1000);
    });
}

function startTimer() {
    resetTimer();

    var seconds = parseInt(timerInput.value);

    if (isNaN(seconds) || seconds <= 0) {
        return;
    }

    timerDisplay.textContent = seconds;

    interval = setInterval(function () {
        seconds--;
        timerDisplay.textContent = seconds;

        if (seconds <= 0) {
            clearInterval(interval);
        }
    }, 1000);

    wait(seconds).then(function (message) {
        customLog(message);
    }).catch(function (error) {
        customLog(error);
    });
}

function resetTimer() {
    clearInterval(interval);

    if (rejectFunction) {
        rejectFunction("Таймер сброшен");
        rejectFunction = null;
    }

    timerDisplay.textContent = "0";
}

startBtn.addEventListener("click", startTimer);
resetBtn.addEventListener("click", resetTimer);
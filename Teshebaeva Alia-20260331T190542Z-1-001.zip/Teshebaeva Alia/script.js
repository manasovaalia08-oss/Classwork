// Находим все нужные элементы
const welcomeTitle = document.getElementById('welcome-title');
const nameInput = document.getElementById('name-input');
const saveBtn = document.getElementById('save-name');

const regForm = document.getElementById('registration-form');
const passError = document.getElementById('password-match-error');

// 1 & 2. Приветствие и проверка при загрузке
function checkUser() {
    const savedName = localStorage.getItem('currentUserName');
    const savedProfile = localStorage.getItem('userProfile');

    if (savedName) {
        welcomeTitle.textContent = `Привет, ${savedName}!`;
    }

    // 5. Если профиль есть, прячем форму и показываем "настройки"
    if (savedProfile) {
        const profileData = JSON.parse(savedProfile);
        
        // Просто заменяем содержимое формы на инфо о профиле
        regForm.parentElement.innerHTML = `
            <h3>Настройки профиля</h3>
            <p>Имя: ${profileData.username}</p>
            <p>Email: ${profileData.email}</p>
            <button id="logout-btn">Выйти</button>
        `;

        // 6. Кнопка Выйти
        document.getElementById('logout-btn').onclick = function() {
            localStorage.clear(); // Удаляем всё
            location.reload();    // Перезагрузка
        };
    }
}

checkUser();

// Кнопка "Запомнить меня" для первого пункта
saveBtn.onclick = function() {
    const name = nameInput.value;
    if (name) {
        localStorage.setItem('currentUserName', name);
        welcomeTitle.textContent = `Привет, ${name}!`;
        alert('Имя сохранено!');
    }
};

// 2, 3 & 4. Обработка формы
regForm.onsubmit = function(event) {
    event.preventDefault(); // Чтобы страница не перезагружалась

    // Получаем данные из полей
    const formData = new FormData(regForm);
    const user = Object.fromEntries(formData.entries());

    // Проверка совпадения паролей
    if (user.password !== user.password2) {
        passError.style.display = 'block';
        return;
    } else {
        passError.style.display = 'none';
    }

    // 4. Сложная валидация пароля (Регулярка)
    // Минимум 8 символов, цифра, заглавная буква и спецсимвол
    const passRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;
    
    if (!passRegex.test(user.password)) {
        alert('Пароль слишком простой! Нужно: 8+ символов, цифра, большая буква и символ (!@#$...).');
        return;
    }

    // Если всё ок:
    // 1. Сохраняем имя отдельно
    localStorage.setItem('currentUserName', user.username);
    
    // 3. Сохраняем весь объект профиля
    localStorage.setItem('userProfile', JSON.stringify(user));

    alert('Успешная регистрация!');
    location.reload(); // Перезагружаем, чтобы сработал checkUser
};
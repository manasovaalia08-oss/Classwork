const mainTitle = document.getElementById('main-title');
const themeBtn = document.querySelector('#theme-toggle');
const addBtn = document.querySelector('#add-btn');
const input = document.querySelector('#user-input');
const list = document.querySelector('#list');
const clearAllBtn = document.querySelector('#clear-all');
const taskCount = document.querySelector('#task-count');

// оформление
mainTitle.textContent = 'Привет студенты, я живой!';
mainTitle.style.color = 'royalblue';
mainTitle.style.fontSize = '40px';

// тема
themeBtn.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});

// счётчик
function updateCount() {
    taskCount.textContent = `Задач: ${list.children.length}`;
}
updateCount();

// добавление задачи 
addBtn.addEventListener('click', () => {
    const text = input.value.trim();
    if (!text) return;

    const li = document.createElement('li');

    const textSpan = document.createElement('span');
    textSpan.textContent = text;
    textSpan.className = 'task-text';

    const date = document.createElement('small');
    date.textContent = ` (${new Date().toLocaleString()})`;

    const editBtn = document.createElement('button');
    editBtn.textContent = 'редактировать';
    editBtn.style.marginLeft = '10px';

    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'удалить';
    deleteBtn.style.marginLeft = '5px';

    // редактирование
    editBtn.addEventListener('click', () => {
        const newText = prompt('Редактировать задачу:', textSpan.textContent);
        if (newText && newText.trim()) {
            textSpan.textContent = newText.trim();
        }
    });

    // удаление
    deleteBtn.addEventListener('click', () => {
        li.remove();
        updateCount();
    });

    li.append(textSpan, date, editBtn, deleteBtn);
    list.append(li);

    input.value = '';
    updateCount();
});

// ENTER 
input.addEventListener('keydown', (e) => {
    if (e.key == 'Enter') addBtn.click();
});

// отметить выполненным 
list.addEventListener('click', (e) => {
    if (e.target.classList.contains('task-text')) {
        e.target.parentElement.classList.toggle('completed');
    }
});

// удалить всё 
clearAllBtn.addEventListener('click', () => {
    list.innerHTML = '';
    updateCount();
});

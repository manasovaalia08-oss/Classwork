const postsContainer = document.getElementById("postsContainer");
const loader = document.getElementById("loader");
const logs = document.getElementById("consoleLogs");

let allPosts = [];

/* ===== GET ===== */
function getPosts(btn) {
    btn.disabled = true;
    loader.style.display = "block";

    const randomCount = Math.floor(Math.random() * 10) + 1;

    fetch(`https://jsonplaceholder.typicode.com/posts?_limit=${randomCount}`)
        .then(res => res.json())
        .then(data => {
            allPosts = data;
            showPosts(allPosts);
            log("GET запрос выполнен");
        })
        .catch(() => {
            showError("⚠️ Произошла ошибка при загрузке данных");
        })
        .finally(() => {
            loader.style.display = "none";
            btn.disabled = false;
        });
}

/* ===== ПОКАЗ ПОСТОВ ===== */
function showPosts(posts) {
    postsContainer.innerHTML = "";

    posts.forEach(post => {
        const div = document.createElement("div");
        div.className = "post-item";

        div.innerHTML = `
            <div class="post-meta">POST ID: ${post.id}</div>
            <h4>${post.title}</h4>
            <p>${post.body}</p>
            <button class="comment-btn" onclick="loadComments(${post.id}, this)">Комментарии</button>
            <button class="delete-btn" onclick="deletePost(${post.id}, this)">Удалить</button>
            <div class="comments"></div>
        `;

        postsContainer.appendChild(div);
    });
}

/* ===== КОММЕНТАРИИ ===== */
function loadComments(postId, btn) {
    const commentBlock = btn.parentElement.querySelector(".comments");

    fetch(`https://jsonplaceholder.typicode.com/comments?postId=${postId}`)
        .then(res => res.json())
        .then(data => {
            commentBlock.innerHTML = data.map(c =>
                `<p><strong>${c.email}</strong>: ${c.body}</p>`
            ).join("");
        });
}

/* ===== POST ===== */
function createPost(btn) {
    btn.disabled = true;

    const title = "Новый тестовый пост";
    const body = "Этот пост создан через POST запрос.";

    fetch("https://jsonplaceholder.typicode.com/posts", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            title,
            body,
            userId: 1
        })
    })
        .then(res => res.json())
        .then(data => {
            alert("Пост успешно создан! ID: " + data.id);
            log("POST выполнен");
        })
        .finally(() => btn.disabled = false);
}

/* ===== DELETE ===== */
function deletePost(id, btn) {
    fetch(`https://jsonplaceholder.typicode.com/posts/${id}`, {
        method: "DELETE"
    })
        .then(() => {
            btn.parentElement.remove();
            log("POST удалён");
        });
}

/* ===== ОЧИСТКА ===== */
function clearAll() {
    postsContainer.innerHTML = "";
    log("Контент очищен");
}

/* ===== ЛОГИ ===== */
function log(text) {
    logs.innerHTML += "> " + text + "<br>";
}

/* ===== ОШИБКА ===== */
function showError(message) {
    postsContainer.innerHTML = `<div class="error-message">${message}</div>`;
}